package exceptions;

public class NullCharacterException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
